package com.snapfix.app

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

private val Bg = Color(0xFF08080D)
private val Card = Color(0xFF15151F)
private val Purple = Color(0xFF9B6CFF)

data class Tool(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SnapFixApp() }
    }
}

@Composable
fun SnapFixApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selected by remember { mutableStateOf<Uri?>(null) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var credits by remember { mutableIntStateOf(10) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf("Choose a photo to begin") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selected = uri
            bitmap = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it)
            }
            result = null
            status = "Photo ready"
        }
    }

    val tools = listOf(
        Tool("Enhance", Icons.Default.AutoFixHigh),
        Tool("Compress", Icons.Default.Compress),
        Tool("OCR", Icons.Default.TextFields),
        Tool("Image → PDF", Icons.Default.PictureAsPdf),
        Tool("Save", Icons.Default.Save),
        Tool("Share", Icons.Default.Share)
    )

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Bg, surface = Card
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = { Text("SNAPFIX", fontWeight = FontWeight.Bold) },
                    actions = {
                        Text("Credits: $credits", color = Purple,
                            modifier = Modifier.padding(end = 16.dp))
                    }
                )
            }
        ) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).padding(16.dp)
            ) {
                Text("Fix your photos in seconds.", 25.sp, fontWeight = FontWeight.Bold)
                Text(status, color = Color.LightGray,
                    modifier = Modifier.padding(top = 4.dp))

                Spacer(Modifier.height(16.dp))

                Button(
                    onClick = { picker.launch("image/*") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PhotoLibrary, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choose Photo")
                }

                Spacer(Modifier.height(12.dp))

                val preview = result ?: bitmap
                if (preview != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Card),
                        modifier = Modifier.fillMaxWidth().height(260.dp)
                    ) {
                        Image(
                            bitmap = preview.asImageBitmap(),
                            contentDescription = "Selected image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("Tools", 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(tools) { tool ->
                        ToolCard(tool) {
                            val src = bitmap
                            if (src == null) {
                                Toast.makeText(context, "Choose a photo first", Toast.LENGTH_SHORT).show()
                                return@ToolCard
                            }

                            when (tool.title) {
                                "Enhance" -> {
                                    if (credits <= 0) {
                                        Toast.makeText(context, "No credits left", Toast.LENGTH_SHORT).show()
                                    } else {
                                        credits--
                                        result = enhance(src)
                                        status = "Enhanced image created"
                                    }
                                }
                                "Compress" -> {
                                    if (credits <= 0) {
                                        Toast.makeText(context, "No credits left", Toast.LENGTH_SHORT).show()
                                    } else {
                                        credits--
                                        val out = compress(src, 65)
                                        val uri = saveJpeg(context, out, "SNAPFIX_COMPRESSED")
                                        status = if (uri != null) "Compressed image saved" else "Save failed"
                                        result = BitmapFactory.decodeByteArray(out, 0, out.size)
                                    }
                                }
                                "Image → PDF" -> {
                                    if (credits <= 0) {
                                        Toast.makeText(context, "No credits left", Toast.LENGTH_SHORT).show()
                                    } else {
                                        credits--
                                        val ok = savePdf(context, src)
                                        status = if (ok) "PDF saved to Documents" else "PDF creation failed"
                                    }
                                }
                                "Save" -> {
                                    val b = result ?: src
                                    val uri = saveBitmap(context, b, "SNAPFIX_IMAGE")
                                    status = if (uri != null) "Image saved to Photos" else "Save failed"
                                }
                                "Share" -> {
                                    val b = result ?: src
                                    val uri = saveBitmap(context, b, "SNAPFIX_SHARE")
                                    if (uri != null) {
                                        val intent = Intent(Intent.ACTION_SEND).apply {
                                            type = "image/jpeg"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(intent, "Share image"))
                                    }
                                }
                                "OCR" -> {
                                    Toast.makeText(
                                        context,
                                        "OCR module is prepared for the next build (ML Kit).",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        }
                    }
                }

                Text("SNAPFIX MVP v0.2.0", color = Color.Gray, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun ToolCard(tool: Tool, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Card),
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(105.dp)
    ) {
        Column(
            Modifier.fillMaxSize().padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(tool.icon, null, tint = Purple, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(7.dp))
            Text(tool.title, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun enhance(src: Bitmap): Bitmap {
    val w = src.width
    val h = src.height
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = android.graphics.ColorMatrixColorFilter(
            android.graphics.ColorMatrix(
                floatArrayOf(
                    1.08f, 0f, 0f, 0f, -8f,
                    0f, 1.08f, 0f, 0f, -8f,
                    0f, 0f, 1.08f, 0f, -8f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    canvas.drawBitmap(src, 0f, 0f, paint)
    return out
}

private fun compress(src: Bitmap, quality: Int): ByteArray {
    val stream = ByteArrayOutputStream()
    src.compress(Bitmap.CompressFormat.JPEG, quality, stream)
    return stream.toByteArray()
}

private fun saveJpeg(context: android.content.Context, bytes: ByteArray, name: String): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SNAPFIX")
    }
    val uri = context.contentResolver.insert(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
    ) ?: return null
    context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
    return uri
}

private fun saveBitmap(context: android.content.Context, bitmap: Bitmap, name: String): Uri? {
    return saveJpeg(context, compress(bitmap, 92), name)
}

private fun savePdf(context: android.content.Context, bitmap: Bitmap): Boolean {
    return try {
        val pageW = 595
        val pageH = 842
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
        val canvas = page.canvas
        val scale = min(
            (pageW - 40).toFloat() / bitmap.width,
            (pageH - 40).toFloat() / bitmap.height
        )
        val dw = bitmap.width * scale
        val dh = bitmap.height * scale
        val left = (pageW - dw) / 2f
        val top = (pageH - dh) / 2f
        canvas.drawBitmap(bitmap, null,
            android.graphics.RectF(left, top, left + dw, top + dh),
            Paint(Paint.ANTI_ALIAS_FLAG))
        doc.finishPage(page)

        val values = ContentValues().apply {
            put(MediaStore.Files.FileColumns.DISPLAY_NAME, "SNAPFIX_${System.currentTimeMillis()}.pdf")
            put(MediaStore.Files.FileColumns.MIME_TYPE, "application/pdf")
            put(MediaStore.Files.FileColumns.RELATIVE_PATH, "Documents/SNAPFIX")
        }
        val uri = context.contentResolver.insert(
            MediaStore.Files.getContentUri("external"), values
        ) ?: return false
        context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
        doc.close()
        true
    } catch (_: Exception) {
        false
    }
}
